# ═══════════════════════════════════════════════
# Zoo Vision — SafeZoo 안전관제 통합 관제보드
# 강의 매핑: 04_06 통합 관제 대시보드 (실습 123~127)
# 디자인: safezoo.css (다크 · 레드 액센트)
# 데이터: zoo_safety.py → logs/zoo_events.csv, control_center_inbox.txt
# ═══════════════════════════════════════════════
#
# 실행: python zoo_vision.py
# (탐지·로그 생성은 zoo_safety.py를 별도로 실행)

from __future__ import annotations

import os
from pathlib import Path
from typing import List, Tuple

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import gradio as gr
import pandas as pd

# ---------------------------------------------------------------------------
# 경로 · 상수
# ---------------------------------------------------------------------------
BASE = Path(__file__).resolve().parent
VIDEO = BASE / "giraffe_cctv.mp4"
LOG_DIR = BASE / "logs"
SNAP_DIR = BASE / "snapshots"
EVENT_CSV = LOG_DIR / "zoo_events.csv"
ALERT_INBOX = LOG_DIR / "control_center_inbox.txt"
CSS_PATH = BASE / "safezoo.css"

CAMERA_ID = "ZOO_CAM_GIRAFFE_01"
REFRESH_SEC = 5
SNAPSHOT_LIMIT = 6
TABLE_LIMIT = 50

EVENT_COLS = [
    "detected_at",
    "camera_id",
    "track_id",
    "object",
    "zone",
    "event_type",
    "severity",
    "message",
    "snapshot_path",
    "confidence",
]

DISPLAY_COLS = {
    "detected_at": "시각",
    "camera_id": "카메라",
    "track_id": "Track",
    "object": "객체",
    "zone": "구역",
    "event_type": "유형",
    "severity": "심각도",
    "message": "메시지",
    "confidence": "신뢰도",
}

CAMERAS = [
    ("CAMERA 01", "사자 방사장", "동물 경계 이탈 감지", False),
    ("CAMERA 02", "기린 관람 구역", "관람객 안전선 침범 · SAFE/DANGER ROI", True),
    ("CAMERA 03", "펭귄 관람 구역", "관람객 위험행동 감지", False),
    ("CAMERA 04", "맹수사 출입 통로", "사람·동물 접근 확인", False),
]


# ---------------------------------------------------------------------------
# 데이터 로드
# ---------------------------------------------------------------------------
def empty_events() -> pd.DataFrame:
    return pd.DataFrame(columns=EVENT_COLS)


def load_events() -> pd.DataFrame:
    if not EVENT_CSV.exists():
        return empty_events()
    try:
        df = pd.read_csv(EVENT_CSV, encoding="utf-8-sig")
    except Exception:
        return empty_events()
    for col in EVENT_COLS:
        if col not in df.columns:
            df[col] = ""
    return df[EVENT_COLS].copy()


def load_inbox() -> str:
    if not ALERT_INBOX.exists():
        return "(관제 알림함 비어 있음 — zoo_safety.py 실행 후 알림이 쌓입니다)"
    text = ALERT_INBOX.read_text(encoding="utf-8").strip()
    return text if text else "(관제 알림함 비어 있음)"


def latest_snapshots(n: int = SNAPSHOT_LIMIT) -> List[str]:
    if not SNAP_DIR.exists():
        return []
    files = sorted(
        SNAP_DIR.glob("alert_*.jpg"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return [str(p) for p in files[:n]]


def high_count(df: pd.DataFrame) -> int:
    if len(df) == 0:
        return 0
    return int((df["severity"].astype(str).str.upper() == "HIGH").sum())


# ---------------------------------------------------------------------------
# KPI · 배너 · 차트 · 테이블
# ---------------------------------------------------------------------------
def count_kpi(df: pd.DataFrame) -> str:
    total = len(df)
    last = str(df.iloc[-1]["detected_at"]) if total else "-"
    cams = df["camera_id"].nunique() if total else 0
    return (
        f"### 총 이벤트 **{total}**건\n"
        f"- HIGH 심각도: **{high_count(df)}**\n"
        f"- 카메라 수: **{cams}**\n"
        f"- 최근 시각: `{last}`"
    )


def camera_status(df: pd.DataFrame) -> str:
    status = "🔴 ALERT" if high_count(df) else "🟢 NORMAL"
    video_badge = "영상 연결" if VIDEO.exists() else "영상 미연결"
    return (
        f"### 카메라 상태\n"
        f"- ID: `{CAMERA_ID}`\n"
        f"- 영상: `{VIDEO.name}` ({video_badge})\n"
        f"- 상태: **{status}**\n"
        f"- 누적 알림: **{len(df)}**건"
    )


def alert_banner(df: pd.DataFrame) -> str:
    if len(df) == 0:
        return (
            '<div class="alert-panel ok">'
            '<span class="alert-icon" aria-hidden="true">✓</span>'
            "<div>"
            "<h3>정상 운영 중</h3>"
            "<p>위험 이벤트가 없습니다. 동물과 관람객 안전을 계속 감시합니다.</p>"
            "</div></div>"
        )
    last = df.iloc[-1]
    return (
        '<div class="alert-panel">'
        '<span class="alert-icon" aria-hidden="true">!</span>'
        "<div>"
        f"<h3>[{last.get('detected_at', '')}] "
        f"{last.get('camera_id', CAMERA_ID)} · "
        f"{last.get('event_type', '-')} "
        f"({str(last.get('severity', '')).upper()})</h3>"
        f"<p>{last.get('message', '')}</p>"
        "</div></div>"
    )


def group_chart(df: pd.DataFrame, col: str, label: str) -> pd.DataFrame:
    if len(df) == 0:
        return pd.DataFrame({label: ["(없음)"], "건수": [0]})
    return (
        df.groupby(col, dropna=False)
        .size()
        .reset_index(name="건수")
        .rename(columns={col: label})
    )


def events_table(df: pd.DataFrame, keyword: str = "") -> pd.DataFrame:
    view = df.copy()
    if keyword and keyword.strip():
        kw = keyword.strip().lower()
        mask = view.astype(str).apply(
            lambda col: col.str.lower().str.contains(kw, na=False)
        ).any(axis=1)
        view = view[mask]
    view = view.tail(TABLE_LIMIT).iloc[::-1].reset_index(drop=True)
    return view.rename(columns=DISPLAY_COLS)[list(DISPLAY_COLS.values())]


def refresh_all(keyword: str = "") -> Tuple:
    """타이머·버튼 공통 갱신. UI outputs 순서와 맞춤."""
    df = load_events()
    kpi = count_kpi(df)
    cam = camera_status(df)
    inbox = load_inbox()
    return (
        alert_banner(df),       # banner
        kpi,                    # live_kpi
        kpi,                    # kpi (통계 탭)
        cam,                    # cam_md
        cam,                    # cam_stat
        group_chart(df, "event_type", "유형"),
        group_chart(df, "severity", "심각도"),
        events_table(df, keyword),
        inbox,                  # inbox_live
        inbox,                  # inbox_full
        latest_snapshots(),
    )


# ---------------------------------------------------------------------------
# 정적 HTML · 테마
# ---------------------------------------------------------------------------
def load_css() -> str:
    if CSS_PATH.exists():
        return CSS_PATH.read_text(encoding="utf-8")
    return ""


def header_html() -> str:
    return """
<div class="sz-header">
  <a class="sz-logo" href="#">SAFEZOO</a>
  <nav class="sz-nav" aria-label="주 메뉴">
    <a class="active" href="#home">홈</a>
    <a href="#cameras">카메라</a>
    <a href="#alerts">안전 알림</a>
  </nav>
  <span class="sz-demo-label">프로토타입 · Zoo Vision</span>
</div>
"""


def hero_html() -> str:
    return """
<section class="sz-hero" id="home">
  <div class="sz-hero-content">
    <span class="sz-eyebrow">SAFEZOO CONTROL CENTER</span>
    <h1>모든 생명을 위한<br />안전한 시선.</h1>
    <p>
      동물과 관람객의 위험을 발견하고,<br />
      알림부터 안전조치까지 한 화면에서 확인하세요.
    </p>
    <div class="sz-actions">
      <a class="sz-btn sz-btn-primary" href="#cameras">카메라 보기</a>
      <a class="sz-btn sz-btn-secondary" href="#alerts">안전 알림 보기</a>
    </div>
  </div>
</section>
"""


def camera_card_html(code: str, title: str, desc: str, live: bool) -> str:
    connected = live and VIDEO.exists()
    badge_cls = "sz-badge live" if connected else "sz-badge"
    badge_text = "LIVE" if connected else "영상 미연결"
    return f"""
<article class="sz-camera-card">
  <div class="sz-camera-preview">
    <span class="{badge_cls}">{badge_text}</span>
    {code}
  </div>
  <div class="sz-camera-info">
    <h3>{title}</h3>
    <p>{desc}</p>
  </div>
</article>
"""


def cameras_html() -> str:
    cards = "".join(camera_card_html(*cam) for cam in CAMERAS)
    return f"""
<section class="sz-section" id="cameras">
  <h2>관제 카메라</h2>
  <div class="sz-camera-grid">{cards}</div>
</section>
"""


def footer_html() -> str:
    return """
<footer class="sz-footer">
  SAFEZOO · 안전관제 프로토타입 · Zoo Vision 연동 · giraffe CCTV / 이벤트 로그
</footer>
"""


def build_theme() -> gr.themes.Base:
    return gr.themes.Base(
        primary_hue=gr.themes.colors.red,
        neutral_hue=gr.themes.colors.zinc,
        font=[gr.themes.GoogleFont("Noto Sans KR"), "Pretendard", "Arial", "sans-serif"],
    ).set(
        body_background_fill="#141414",
        body_background_fill_dark="#141414",
        body_text_color="#ffffff",
        body_text_color_dark="#ffffff",
        block_background_fill="#232323",
        block_background_fill_dark="#232323",
        block_border_color="#ffffff14",
        block_border_color_dark="#ffffff14",
        block_label_text_color="#b3b3b3",
        block_title_text_color="#ffffff",
        border_color_primary="#ffffff22",
        button_primary_background_fill="#ffffff",
        button_primary_text_color="#141414",
        button_primary_background_fill_hover="#dddddd",
        input_background_fill="#232323",
        input_border_color="#ffffff22",
    )


# ---------------------------------------------------------------------------
# Gradio UI
# ---------------------------------------------------------------------------
def build_live_tab():
    with gr.Tab("실시간 감시"):
        with gr.Row():
            with gr.Column(scale=2, min_width=400):
                gr.Markdown("### 기린 관람 구역 · LIVE")
                if VIDEO.exists():
                    gr.Video(
                        value=str(VIDEO),
                        autoplay=True,
                        loop=True,
                        show_label=False,
                    )
                else:
                    gr.Markdown("⚠ 영상 없음 — `giraffe_cctv.mp4`를 zoo 폴더에 두세요.")
                gr.Markdown("#### 최근 알림 스냅샷")
                gallery = gr.Gallery(
                    label="스냅샷",
                    columns=3,
                    height=220,
                    object_fit="contain",
                    preview=True,
                )
            with gr.Column(scale=1, min_width=250):
                cam_md = gr.Markdown(elem_classes=["panel-box"])
                live_kpi = gr.Markdown(elem_classes=["panel-box"])
                gr.Markdown("#### 관제센터 알림함")
                inbox_live = gr.Textbox(
                    lines=12,
                    max_lines=20,
                    interactive=False,
                    show_label=False,
                )
    return gallery, cam_md, live_kpi, inbox_live


def build_stats_tab():
    with gr.Tab("통계"):
        with gr.Row():
            kpi = gr.Markdown(elem_classes=["panel-box"])
            cam_stat = gr.Markdown(elem_classes=["panel-box"])
        with gr.Row():
            chart_type = gr.BarPlot(
                x="유형",
                y="건수",
                title="이벤트 유형별 건수",
                x_title="유형",
                y_title="건수",
            )
            chart_sev = gr.BarPlot(
                x="심각도",
                y="건수",
                title="심각도별 건수",
                x_title="심각도",
                y_title="건수",
            )
    return kpi, cam_stat, chart_type, chart_sev


def build_events_tab():
    with gr.Tab("이벤트 기록"):
        with gr.Row():
            kw = gr.Textbox(
                label="검색 (유형·카메라·메시지·객체…)",
                placeholder="예: ZONE_EXIT / giraffe / HIGH",
                scale=4,
            )
            btn = gr.Button("새로고침", variant="primary", scale=1)
        table = gr.Dataframe(interactive=False, wrap=True)
        gr.Markdown("#### 관제센터 알림함 전문")
        inbox_full = gr.Textbox(lines=14, interactive=False, show_label=False)
    return kw, btn, table, inbox_full


def build_app() -> gr.Blocks:
    with gr.Blocks(
        title="SafeZoo 안전관제",
        theme=build_theme(),
        css=load_css(),
    ) as demo:
        gr.HTML(header_html())
        gr.HTML(hero_html())
        banner = gr.HTML(elem_id="alerts")
        gr.HTML(cameras_html())

        with gr.Tabs(elem_classes=["dark-tabs"]):
            gallery, cam_md, live_kpi, inbox_live = build_live_tab()
            kpi, cam_stat, chart_type, chart_sev = build_stats_tab()
            kw, btn, table, inbox_full = build_events_tab()

        gr.HTML(footer_html())

        outputs = [
            banner,
            live_kpi,
            kpi,
            cam_md,
            cam_stat,
            chart_type,
            chart_sev,
            table,
            inbox_live,
            inbox_full,
            gallery,
        ]

        demo.load(fn=lambda: refresh_all(""), inputs=None, outputs=outputs)
        btn.click(fn=refresh_all, inputs=kw, outputs=outputs)
        kw.change(fn=refresh_all, inputs=kw, outputs=outputs)

        timer = gr.Timer(REFRESH_SEC)
        timer.tick(fn=refresh_all, inputs=kw, outputs=outputs)

    return demo


def main() -> None:
    print("SafeZoo · Zoo Vision 통합 관제보드")
    print("  이벤트 CSV :", EVENT_CSV)
    print("  관제 알림함:", ALERT_INBOX)
    print("  영상      :", VIDEO)
    print("  CSS       :", CSS_PATH)
    print(f"  자동 갱신  : {REFRESH_SEC}초")
    build_app().launch()


if __name__ == "__main__":
    main()
